#!/bin/bash

# 安装验证脚本

set -e

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

echo "========================================"
echo "🔍 机器人控制上位机安装验证"
echo "========================================"
echo ""

# 检查系统信息
log_info "系统信息:"
echo "  操作系统: $(lsb_release -d | cut -f2)"
echo "  内核版本: $(uname -r)"
echo "  架构: $(uname -m)"
echo ""

# 检查基础工具
log_info "检查基础工具..."
tools=("gcc" "g++" "make" "git" "wget" "curl")
for tool in "${tools[@]}"; do
    if command -v "$tool" &> /dev/null; then
        echo "  ✓ $tool"
    else
        echo "  ✗ $tool (未安装)"
    fi
done
echo ""

# 检查Qt环境
log_info "检查Qt环境..."
if command -v qmake &> /dev/null; then
    echo "  ✓ qmake: $(qmake --version | head -1)"
    
    # 检查Qt模块
    qt_modules=("QtCore" "QtWidgets" "QtNetwork" "QtSerialPort")
    for module in "${qt_modules[@]}"; do
        if pkg-config --exists Qt5${module#Qt} 2>/dev/null; then
            echo "  ✓ $module"
        else
            echo "  ✗ $module (未安装)"
        fi
    done
else
    log_error "  ✗ qmake未找到"
fi
echo ""

# 检查Python环境
log_info "检查Python环境..."
if command -v python3 &> /dev/null; then
    echo "  ✓ Python: $(python3 --version)"
else
    log_error "  ✗ Python3未找到"
fi

if command -v conda &> /dev/null; then
    echo "  ✓ Conda: $(conda --version)"
    
    # 检查robot_control环境
    if conda env list | grep -q robot_control; then
        echo "  ✓ robot_control环境已创建"
    else
        log_warn "  ⚠ robot_control环境未创建"
    fi
else
    log_warn "  ⚠ Conda未找到"
fi
echo ""

# 检查项目文件
log_info "检查项目文件..."
project_dir="$HOME/robot_control_gui"
if [ -d "$project_dir" ]; then
    echo "  ✓ 项目目录: $project_dir"
    
    cd "$project_dir"
    
    # 检查源代码文件
    source_files=("main.cpp" "mainwindow.cpp" "robotcontroller.cpp" "jointcontrolwidget.cpp" "robot_control_gui.pro")
    for file in "${source_files[@]}"; do
        if [ -f "$file" ]; then
            echo "  ✓ $file"
        else
            log_warn "  ⚠ $file (缺失)"
        fi
    done
    
    # 检查Python文件
    python_files=("robot_simulator.py" "run_headless_demo.py")
    for file in "${python_files[@]}"; do
        if [ -f "$file" ]; then
            echo "  ✓ $file"
        else
            log_warn "  ⚠ $file (缺失)"
        fi
    done
    
    # 检查脚本文件
    script_files=("build_project.sh" "start_demo.sh")
    for file in "${script_files[@]}"; do
        if [ -f "$file" ] && [ -x "$file" ]; then
            echo "  ✓ $file (可执行)"
        else
            log_warn "  ⚠ $file (缺失或不可执行)"
        fi
    done
    
    # 检查编译状态
    if [ -f "robot_control_gui" ]; then
        echo "  ✓ robot_control_gui (已编译)"
    else
        log_warn "  ⚠ robot_control_gui (未编译)"
    fi
    
else
    log_error "  ✗ 项目目录不存在: $project_dir"
fi
echo ""

# 检查网络连接
log_info "检查网络连接..."
if ping -c 1 8.8.8.8 &> /dev/null; then
    echo "  ✓ 网络连接正常"
else
    log_warn "  ⚠ 网络连接异常"
fi
echo ""

# 检查端口占用
log_info "检查端口占用..."
if netstat -tuln 2>/dev/null | grep -q ":8080 "; then
    log_warn "  ⚠ 端口8080已被占用"
else
    echo "  ✓ 端口8080可用"
fi
echo ""

# 总结
echo "========================================"
echo "📋 验证总结"
echo "========================================"
echo ""

# 给出建议
if command -v qmake &> /dev/null && command -v python3 &> /dev/null; then
    log_info "✅ 基础环境检查通过"
    echo ""
    echo "🚀 建议的下一步操作:"
    echo "  1. cd $project_dir"
    echo "  2. ./build_project.sh"
    echo "  3. ./start_demo.sh"
else
    log_error "❌ 环境检查未通过"
    echo ""
    echo "🔧 建议的修复操作:"
    echo "  1. 重新运行环境安装脚本"
    echo "  2. 检查错误日志"
    echo "  3. 手动安装缺失的组件"
fi

echo ""
echo "========================================"
