/****************************************************************************
** Meta object code from reading C++ file 'robotcontroller.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.8)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "robotcontroller.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'robotcontroller.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.8. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_RobotController_t {
    QByteArrayData data[17];
    char stringdata0[240];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RobotController_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RobotController_t qt_meta_stringdata_RobotController = {
    {
QT_MOC_LITERAL(0, 0, 15), // "RobotController"
QT_MOC_LITERAL(1, 16, 23), // "connectionStatusChanged"
QT_MOC_LITERAL(2, 40, 0), // ""
QT_MOC_LITERAL(3, 41, 9), // "connected"
QT_MOC_LITERAL(4, 51, 18), // "robotStatusUpdated"
QT_MOC_LITERAL(5, 70, 11), // "RobotStatus"
QT_MOC_LITERAL(6, 82, 6), // "status"
QT_MOC_LITERAL(7, 89, 20), // "jointPositionChanged"
QT_MOC_LITERAL(8, 110, 7), // "jointId"
QT_MOC_LITERAL(9, 118, 8), // "position"
QT_MOC_LITERAL(10, 127, 13), // "errorOccurred"
QT_MOC_LITERAL(11, 141, 5), // "error"
QT_MOC_LITERAL(12, 147, 17), // "updateRobotStatus"
QT_MOC_LITERAL(13, 165, 20), // "onSerialDataReceived"
QT_MOC_LITERAL(14, 186, 17), // "onTcpDataReceived"
QT_MOC_LITERAL(15, 204, 17), // "onUdpDataReceived"
QT_MOC_LITERAL(16, 222, 17) // "onConnectionError"

    },
    "RobotController\0connectionStatusChanged\0"
    "\0connected\0robotStatusUpdated\0RobotStatus\0"
    "status\0jointPositionChanged\0jointId\0"
    "position\0errorOccurred\0error\0"
    "updateRobotStatus\0onSerialDataReceived\0"
    "onTcpDataReceived\0onUdpDataReceived\0"
    "onConnectionError"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RobotController[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       9,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   59,    2, 0x06 /* Public */,
       4,    1,   62,    2, 0x06 /* Public */,
       7,    2,   65,    2, 0x06 /* Public */,
      10,    1,   70,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    0,   73,    2, 0x08 /* Private */,
      13,    0,   74,    2, 0x08 /* Private */,
      14,    0,   75,    2, 0x08 /* Private */,
      15,    0,   76,    2, 0x08 /* Private */,
      16,    0,   77,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, 0x80000000 | 5,    6,
    QMetaType::Void, QMetaType::Int, QMetaType::Double,    8,    9,
    QMetaType::Void, QMetaType::QString,   11,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void RobotController::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<RobotController *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->connectionStatusChanged((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->robotStatusUpdated((*reinterpret_cast< const RobotStatus(*)>(_a[1]))); break;
        case 2: _t->jointPositionChanged((*reinterpret_cast< int(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 3: _t->errorOccurred((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->updateRobotStatus(); break;
        case 5: _t->onSerialDataReceived(); break;
        case 6: _t->onTcpDataReceived(); break;
        case 7: _t->onUdpDataReceived(); break;
        case 8: _t->onConnectionError(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (RobotController::*)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RobotController::connectionStatusChanged)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (RobotController::*)(const RobotStatus & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RobotController::robotStatusUpdated)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (RobotController::*)(int , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RobotController::jointPositionChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (RobotController::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&RobotController::errorOccurred)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject RobotController::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_RobotController.data,
    qt_meta_data_RobotController,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *RobotController::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RobotController::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_RobotController.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int RobotController::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 9)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 9;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 9)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 9;
    }
    return _id;
}

// SIGNAL 0
void RobotController::connectionStatusChanged(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void RobotController::robotStatusUpdated(const RobotStatus & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void RobotController::jointPositionChanged(int _t1, double _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void RobotController::errorOccurred(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
