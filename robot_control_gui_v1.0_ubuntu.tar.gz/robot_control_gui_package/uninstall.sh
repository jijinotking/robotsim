#!/bin/bash

# 卸载脚本

set -e

# 颜色定义
GREEN='\033[0;32m'
RED='\033[0;31m'
YELLOW='\033[1;33m'
NC='\033[0m'

log_info() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[WARN]${NC} $1"
}

echo "========================================"
echo "🗑️  机器人控制上位机卸载程序"
echo "========================================"
echo ""

log_warn "这将删除以下内容:"
echo "  - 项目目录: $HOME/robot_control_gui"
echo "  - Conda环境: robot_control"
echo "  - 相关环境变量"
echo ""
echo "注意: 不会卸载系统级别的包 (Qt5, Miniconda等)"
echo ""

read -p "确定要继续卸载吗？(y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    log_info "卸载已取消"
    exit 0
fi

# 删除项目目录
if [ -d "$HOME/robot_control_gui" ]; then
    log_info "删除项目目录..."
    rm -rf "$HOME/robot_control_gui"
    echo "  ✓ 项目目录已删除"
fi

# 删除conda环境
if command -v conda &> /dev/null; then
    source "$HOME/miniconda3/etc/profile.d/conda.sh" 2>/dev/null || true
    if conda env list | grep -q robot_control; then
        log_info "删除conda环境..."
        conda env remove -n robot_control -y
        echo "  ✓ robot_control环境已删除"
    fi
fi

# 清理环境变量 (可选)
read -p "是否清理bashrc中的相关环境变量？(y/N): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    log_info "清理环境变量..."
    
    # 备份bashrc
    cp "$HOME/.bashrc" "$HOME/.bashrc.backup.$(date +%Y%m%d_%H%M%S)"
    
    # 删除conda相关行
    sed -i '/# >>> conda initialize >>>/,/# <<< conda initialize <<</d' "$HOME/.bashrc"
    
    # 删除Qt相关行
    sed -i '/# Qt环境变量/d' "$HOME/.bashrc"
    sed -i '/export QT_QPA_PLATFORM/d' "$HOME/.bashrc"
    
    echo "  ✓ 环境变量已清理"
    echo "  ✓ bashrc备份已保存"
fi

echo ""
echo "========================================"
echo "✅ 卸载完成"
echo "========================================"
echo ""
echo "如果需要完全清理系统，还可以手动执行:"
echo "  sudo apt remove qtbase5-dev qtcreator"
echo "  rm -rf ~/miniconda3"
echo ""
echo "感谢使用机器人控制上位机！"
echo "========================================"
