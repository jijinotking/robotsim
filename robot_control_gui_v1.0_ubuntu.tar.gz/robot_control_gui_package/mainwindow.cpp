#include "mainwindow.h"
#include <QApplication>
#include <QMessageBox>
#include <QFileDialog>
#include <QSettings>
#include <QDateTime>
#include <QSplitter>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , m_centralWidget(nullptr)
    , m_robotController(nullptr)
    , m_statusUpdateTimer(nullptr)
{
    setWindowTitle("机器人运动控制上位机 v1.0");
    setMinimumSize(1200, 800);
    resize(1400, 900);
    
    // 初始化机器人控制器
    m_robotController = new RobotController(this);
    connect(m_robotController, &RobotController::connectionStatusChanged,
            this, &MainWindow::onRobotStatusChanged);
    
    // 设置UI
    setupUI();
    setupMenuBar();
    setupStatusBar();
    
    // 设置状态更新定时器
    m_statusUpdateTimer = new QTimer(this);
    connect(m_statusUpdateTimer, &QTimer::timeout, this, &MainWindow::updateRobotStatus);
    m_statusUpdateTimer->start(100); // 100ms更新一次
    
    // 初始状态
    onRobotStatusChanged(false);
}

MainWindow::~MainWindow()
{
}

void MainWindow::setupUI()
{
    m_centralWidget = new QWidget;
    setCentralWidget(m_centralWidget);
    
    // 创建主分割器
    m_mainSplitter = new QSplitter(Qt::Horizontal, this);
    
    // 创建关节控制区域
    setupJointControls();
    
    // 创建控制面板
    setupControlPanel();
    
    // 创建日志面板
    setupLogPanel();
    
    // 设置布局
    QHBoxLayout *mainLayout = new QHBoxLayout(m_centralWidget);
    mainLayout->addWidget(m_mainSplitter);
    
    // 设置分割器比例
    m_mainSplitter->setSizes({800, 400});
}

void MainWindow::setupJointControls()
{
    // 创建标签页控件
    m_jointTabWidget = new QTabWidget;
    
    // 创建滚动区域
    m_scrollArea = new QScrollArea;
    m_scrollArea->setWidgetResizable(true);
    m_scrollArea->setHorizontalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    m_scrollArea->setVerticalScrollBarPolicy(Qt::ScrollBarAsNeeded);
    
    QWidget *jointControlWidget = new QWidget;
    QVBoxLayout *jointLayout = new QVBoxLayout(jointControlWidget);
    
    // 创建各个关节组
    createJointControlGroup("左臂关节 (8个)", 0, 8, jointControlWidget);
    createJointControlGroup("右臂关节 (8个)", 8, 8, jointControlWidget);
    createJointControlGroup("腰部关节 (2个)", 16, 2, jointControlWidget);
    createJointControlGroup("底盘电机 (2个)", 18, 2, jointControlWidget);
    createJointControlGroup("升降机构 (1个)", 20, 1, jointControlWidget);
    
    jointLayout->addStretch();
    m_scrollArea->setWidget(jointControlWidget);
    
    m_jointTabWidget->addTab(m_scrollArea, "关节控制");
    
    // 添加到主分割器
    m_mainSplitter->addWidget(m_jointTabWidget);
}

void MainWindow::createJointControlGroup(const QString &groupName, int startJoint, int jointCount, QWidget *parent)
{
    QGroupBox *group = new QGroupBox(groupName);
    QGridLayout *layout = new QGridLayout(group);
    
    for (int i = 0; i < jointCount; ++i) {
        int jointId = startJoint + i;
        QString jointName = QString("关节 %1").arg(jointId + 1);
        
        JointControlWidget *jointControl = new JointControlWidget(jointId, jointName);
        connect(jointControl, &JointControlWidget::valueChanged,
                this, &MainWindow::onJointValueChanged);
        
        m_jointControls.append(jointControl);
        
        int row = i / 2;
        int col = i % 2;
        layout->addWidget(jointControl, row, col);
    }
    
    parent->layout()->addWidget(group);
}

void MainWindow::setupControlPanel()
{
    QWidget *controlWidget = new QWidget;
    QVBoxLayout *controlLayout = new QVBoxLayout(controlWidget);
    
    // 连接控制组
    QGroupBox *connectionGroup = new QGroupBox("连接控制");
    QVBoxLayout *connLayout = new QVBoxLayout(connectionGroup);
    
    m_connectBtn = new QPushButton("连接机器人");
    m_disconnectBtn = new QPushButton("断开连接");
    m_emergencyStopBtn = new QPushButton("紧急停止");
    m_emergencyStopBtn->setStyleSheet("QPushButton { background-color: #ff4444; color: white; font-weight: bold; }");
    
    connLayout->addWidget(m_connectBtn);
    connLayout->addWidget(m_disconnectBtn);
    connLayout->addWidget(m_emergencyStopBtn);
    
    // 位置控制组
    QGroupBox *positionGroup = new QGroupBox("位置控制");
    QVBoxLayout *posLayout = new QVBoxLayout(positionGroup);
    
    m_resetZeroBtn = new QPushButton("复位到零位");
    m_savePositionBtn = new QPushButton("保存当前位置");
    m_loadPositionBtn = new QPushButton("加载位置");
    
    posLayout->addWidget(m_resetZeroBtn);
    posLayout->addWidget(m_savePositionBtn);
    posLayout->addWidget(m_loadPositionBtn);
    
    // 关节控制组
    QGroupBox *jointGroup = new QGroupBox("关节控制");
    QVBoxLayout *jointLayout = new QVBoxLayout(jointGroup);
    
    m_enableAllBtn = new QPushButton("使能所有关节");
    m_disableAllBtn = new QPushButton("失能所有关节");
    
    jointLayout->addWidget(m_enableAllBtn);
    jointLayout->addWidget(m_disableAllBtn);
    
    // 状态显示组
    QGroupBox *statusGroup = new QGroupBox("状态信息");
    QVBoxLayout *statusLayout = new QVBoxLayout(statusGroup);
    
    m_connectionStatusLabel = new QLabel("连接状态: 未连接");
    m_robotStatusLabel = new QLabel("机器人状态: 离线");
    
    QLabel *batteryLabel = new QLabel("电池电量:");
    m_batteryLevel = new QProgressBar;
    m_batteryLevel->setRange(0, 100);
    m_batteryLevel->setValue(0);
    
    statusLayout->addWidget(m_connectionStatusLabel);
    statusLayout->addWidget(m_robotStatusLabel);
    statusLayout->addWidget(batteryLabel);
    statusLayout->addWidget(m_batteryLevel);
    
    // 添加到控制布局
    controlLayout->addWidget(connectionGroup);
    controlLayout->addWidget(positionGroup);
    controlLayout->addWidget(jointGroup);
    controlLayout->addWidget(statusGroup);
    controlLayout->addStretch();
    
    // 连接信号槽
    connect(m_connectBtn, &QPushButton::clicked, this, &MainWindow::connectToRobot);
    connect(m_disconnectBtn, &QPushButton::clicked, this, &MainWindow::disconnectFromRobot);
    connect(m_emergencyStopBtn, &QPushButton::clicked, this, &MainWindow::emergencyStop);
    connect(m_resetZeroBtn, &QPushButton::clicked, this, &MainWindow::resetToZeroPosition);
    connect(m_savePositionBtn, &QPushButton::clicked, this, &MainWindow::saveCurrentPosition);
    connect(m_loadPositionBtn, &QPushButton::clicked, this, &MainWindow::loadPosition);
    connect(m_enableAllBtn, &QPushButton::clicked, this, &MainWindow::enableAllJoints);
    connect(m_disableAllBtn, &QPushButton::clicked, this, &MainWindow::disableAllJoints);
    
    m_mainSplitter->addWidget(controlWidget);
}

void MainWindow::setupLogPanel()
{
    QWidget *logWidget = new QWidget;
    QVBoxLayout *logLayout = new QVBoxLayout(logWidget);
    
    QLabel *logLabel = new QLabel("系统日志:");
    m_logTextEdit = new QTextEdit;
    m_logTextEdit->setMaximumHeight(200);
    m_logTextEdit->setReadOnly(true);
    
    logLayout->addWidget(logLabel);
    logLayout->addWidget(m_logTextEdit);
    
    // 添加到控制面板的底部
    QWidget *controlWidget = qobject_cast<QWidget*>(m_mainSplitter->widget(1));
    if (controlWidget) {
        controlWidget->layout()->addWidget(logWidget);
    }
    
    // 添加初始日志
    m_logTextEdit->append(QString("[%1] 系统启动").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
}

void MainWindow::setupMenuBar()
{
    // 文件菜单
    m_fileMenu = menuBar()->addMenu("文件(&F)");
    m_exitAction = new QAction("退出(&X)", this);
    m_exitAction->setShortcut(QKeySequence::Quit);
    connect(m_exitAction, &QAction::triggered, this, &QWidget::close);
    m_fileMenu->addAction(m_exitAction);
    
    // 机器人菜单
    m_robotMenu = menuBar()->addMenu("机器人(&R)");
    m_connectAction = new QAction("连接(&C)", this);
    m_disconnectAction = new QAction("断开连接(&D)", this);
    m_emergencyStopAction = new QAction("紧急停止(&E)", this);
    m_emergencyStopAction->setShortcut(QKeySequence("F1"));
    
    connect(m_connectAction, &QAction::triggered, this, &MainWindow::connectToRobot);
    connect(m_disconnectAction, &QAction::triggered, this, &MainWindow::disconnectFromRobot);
    connect(m_emergencyStopAction, &QAction::triggered, this, &MainWindow::emergencyStop);
    
    m_robotMenu->addAction(m_connectAction);
    m_robotMenu->addAction(m_disconnectAction);
    m_robotMenu->addSeparator();
    m_robotMenu->addAction(m_emergencyStopAction);
    
    // 帮助菜单
    m_helpMenu = menuBar()->addMenu("帮助(&H)");
    m_aboutAction = new QAction("关于(&A)", this);
    connect(m_aboutAction, &QAction::triggered, [this]() {
        QMessageBox::about(this, "关于", 
            "机器人运动控制上位机 v1.0\n\n"
            "支持轮臂机器人控制:\n"
            "- 左臂: 8个关节\n"
            "- 右臂: 8个关节\n"
            "- 腰部: 2个关节\n"
            "- 底盘: 2个电机\n"
            "- 升降: 1个电机\n\n"
            "总计21个自由度");
    });
    m_helpMenu->addAction(m_aboutAction);
}

void MainWindow::setupStatusBar()
{
    statusBar()->showMessage("就绪");
}

void MainWindow::connectToRobot()
{
    m_logTextEdit->append(QString("[%1] 正在连接机器人...").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
    
    if (m_robotController->connectToRobot()) {
        m_logTextEdit->append(QString("[%1] 机器人连接成功").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
        statusBar()->showMessage("已连接到机器人");
    } else {
        m_logTextEdit->append(QString("[%1] 机器人连接失败").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
        QMessageBox::warning(this, "连接失败", "无法连接到机器人，请检查连接设置。");
    }
}

void MainWindow::disconnectFromRobot()
{
    m_robotController->disconnectFromRobot();
    m_logTextEdit->append(QString("[%1] 已断开机器人连接").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
    statusBar()->showMessage("已断开连接");
}

void MainWindow::emergencyStop()
{
    m_robotController->emergencyStop();
    m_logTextEdit->append(QString("[%1] 紧急停止已激活").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
    QMessageBox::warning(this, "紧急停止", "紧急停止已激活！所有运动已停止。");
}

void MainWindow::resetToZeroPosition()
{
    m_robotController->resetToZeroPosition();
    
    // 更新UI显示
    for (auto *jointControl : m_jointControls) {
        jointControl->setValue(0.0);
    }
    
    m_logTextEdit->append(QString("[%1] 机器人已复位到零位").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
}

void MainWindow::saveCurrentPosition()
{
    QString fileName = QFileDialog::getSaveFileName(this, "保存位置", "", "位置文件 (*.pos)");
    if (!fileName.isEmpty()) {
        QSettings settings(fileName, QSettings::IniFormat);
        
        for (int i = 0; i < m_jointControls.size(); ++i) {
            settings.setValue(QString("joint_%1").arg(i), m_jointControls[i]->getValue());
        }
        
        m_logTextEdit->append(QString("[%1] 位置已保存到: %2").arg(QDateTime::currentDateTime().toString("hh:mm:ss"), fileName));
    }
}

void MainWindow::loadPosition()
{
    QString fileName = QFileDialog::getOpenFileName(this, "加载位置", "", "位置文件 (*.pos)");
    if (!fileName.isEmpty()) {
        QSettings settings(fileName, QSettings::IniFormat);
        
        for (int i = 0; i < m_jointControls.size(); ++i) {
            double value = settings.value(QString("joint_%1").arg(i), 0.0).toDouble();
            m_jointControls[i]->setValue(value);
            m_robotController->setJointPosition(i, value);
        }
        
        m_logTextEdit->append(QString("[%1] 位置已从文件加载: %2").arg(QDateTime::currentDateTime().toString("hh:mm:ss"), fileName));
    }
}

void MainWindow::enableAllJoints()
{
    for (auto *jointControl : m_jointControls) {
        jointControl->setEnabled(true);
    }
    m_robotController->enableAllJoints();
    m_logTextEdit->append(QString("[%1] 所有关节已使能").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
}

void MainWindow::disableAllJoints()
{
    for (auto *jointControl : m_jointControls) {
        jointControl->setEnabled(false);
    }
    m_robotController->disableAllJoints();
    m_logTextEdit->append(QString("[%1] 所有关节已失能").arg(QDateTime::currentDateTime().toString("hh:mm:ss")));
}

void MainWindow::onRobotStatusChanged(bool connected)
{
    m_connectBtn->setEnabled(!connected);
    m_disconnectBtn->setEnabled(connected);
    m_resetZeroBtn->setEnabled(connected);
    m_savePositionBtn->setEnabled(connected);
    m_loadPositionBtn->setEnabled(connected);
    m_enableAllBtn->setEnabled(connected);
    m_disableAllBtn->setEnabled(connected);
    
    m_connectAction->setEnabled(!connected);
    m_disconnectAction->setEnabled(connected);
    
    if (connected) {
        m_connectionStatusLabel->setText("连接状态: 已连接");
        m_robotStatusLabel->setText("机器人状态: 在线");
        m_connectionStatusLabel->setStyleSheet("color: green;");
    } else {
        m_connectionStatusLabel->setText("连接状态: 未连接");
        m_robotStatusLabel->setText("机器人状态: 离线");
        m_connectionStatusLabel->setStyleSheet("color: red;");
        m_batteryLevel->setValue(0);
    }
}

void MainWindow::onJointValueChanged(int jointId, double value)
{
    m_robotController->setJointPosition(jointId, value);
}

void MainWindow::updateRobotStatus()
{
    if (m_robotController->isConnected()) {
        // 更新电池电量（模拟数据）
        static int batteryValue = 85;
        m_batteryLevel->setValue(batteryValue);
        
        // 更新关节位置反馈（如果有的话）
        // 这里可以从机器人控制器获取实际的关节位置反馈
    }
}