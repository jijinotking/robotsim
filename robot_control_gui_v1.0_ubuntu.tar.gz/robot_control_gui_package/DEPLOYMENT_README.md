# 机器人运动控制上位机 - 部署包

## 系统要求
- Ubuntu 18.04/20.04/22.04
- 至少2GB可用磁盘空间
- 网络连接（用于下载依赖）

## 快速部署

### 1. 解压部署包
```bash
tar -xzf robot_control_gui_v1.0_ubuntu.tar.gz
cd robot_control_gui_package
```

### 2. 运行环境安装脚本
```bash
chmod +x setup_ubuntu_environment.sh
./setup_ubuntu_environment.sh
```

### 3. 编译和运行
```bash
# 重新加载环境变量
source ~/.bashrc

# 进入项目目录
cd ~/robot_control_gui

# 编译项目
./build_project.sh

# 运行演示
./start_demo.sh
```

## 文件说明

### 核心源代码
- `main.cpp` - 主程序入口
- `mainwindow.h/cpp` - 主窗口实现
- `robotcontroller.h/cpp` - 机器人控制器
- `jointcontrolwidget.h/cpp` - 关节控制组件
- `robot_control_gui.pro` - Qt项目文件
- `mainwindow.ui` - UI界面文件

### Python模拟器
- `robot_simulator.py` - 机器人模拟器
- `run_headless_demo.py` - 无头模式演示

### 部署脚本
- `setup_ubuntu_environment.sh` - 环境安装脚本
- `build_project.sh` - 编译脚本
- `start_demo.sh` - 启动脚本

### 文档
- `README.md` - 项目说明
- `PROJECT_SUMMARY.md` - 项目总结
- `DEPLOYMENT_README.md` - 部署说明（本文件）

## 功能特性

### 机器人配置
- 左臂: 8个关节 (ID: 0-7)
- 右臂: 8个关节 (ID: 8-15)
- 腰部: 2个关节 (ID: 16-17)
- 底盘: 2个电机 (ID: 18-19)
- 升降: 1个电机 (ID: 20)

### 主要功能
- 实时关节角度控制
- 机器人零位设置
- 位置保存/加载
- 紧急停止功能
- 多种通信协议支持
- 图形界面和命令行模式

## 故障排除

### 常见问题

1. **编译失败**
   - 确保Qt5正确安装: `qmake --version`
   - 检查依赖包: `sudo apt install qtbase5-dev`

2. **无法运行图形界面**
   - 检查显示环境: `echo $DISPLAY`
   - 使用无头模式: 选择启动脚本中的选项3

3. **Python环境问题**
   - 激活conda环境: `conda activate robot_control`
   - 检查Python版本: `python --version`

4. **网络连接问题**
   - 检查防火墙设置
   - 确认端口8080未被占用

### 获取帮助
如果遇到问题，请检查：
1. 系统日志: `journalctl -f`
2. 应用日志: 查看终端输出
3. 环境变量: `env | grep -E "(PATH|QT|CONDA)"`

## 版本信息
- 版本: 1.0
- 支持系统: Ubuntu 18.04/20.04/22.04
- Qt版本: 5.15+
- Python版本: 3.9+

## 许可证
MIT License - 详见项目文档
